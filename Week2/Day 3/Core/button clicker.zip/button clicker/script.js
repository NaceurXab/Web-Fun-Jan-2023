function change(element){
    element.innerText = "logout";
}
function hide(element){
    element.remove();
}